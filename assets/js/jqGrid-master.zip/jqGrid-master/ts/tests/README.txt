One should compile the file `test.ts` having the package root as the current directory:
```
tsc --sourcemap --target ES5 ts\tests\test.ts
```